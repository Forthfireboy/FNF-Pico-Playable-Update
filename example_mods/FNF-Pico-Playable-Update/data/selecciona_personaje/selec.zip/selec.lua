function onCreate()
    setProperty('skipCountdown', true)

    makeLuaSprite('bgrefe', 'freeplay/lock/bg', 0, 0)
    setObjectCamera('bgrefe', 'other')
    addLuaSprite('bgrefe', true)
    
    -- lock
    makeLuaSprite('lock1', 'freeplay/lock/1', 470, 150)
    setObjectCamera('lock1', 'other')
    addLuaSprite('lock1', true)
    
    makeLuaSprite('lock2', 'freeplay/lock/2', 580, 150)
    setObjectCamera('lock2', 'other')
    addLuaSprite('lock2', true)
    
    makeLuaSprite('lock3', 'freeplay/lock/3', 682, 150)
    setObjectCamera('lock3', 'other')
    addLuaSprite('lock3', true)
    
    makeLuaSprite('lock4', 'freeplay/lock/4', 485, 285)
    setObjectCamera('lock4', 'other')
    addLuaSprite('lock4', true)
    
    makeLuaSprite('lock5', 'freeplay/lock/5', 578, 287)
    setObjectCamera('lock5', 'other')
    addLuaSprite('lock5', true)
    
    makeLuaSprite('lock6', 'freeplay/lock/6', 682, 277)
    setObjectCamera('lock6', 'other')
    addLuaSprite('lock6', true)
    
    makeLuaSprite('lock7', 'freeplay/lock/7', 470, 405)
    setObjectCamera('lock7', 'other')
    addLuaSprite('lock7', true)
    
    makeLuaSprite('lock8', 'freeplay/lock/8', 580, 405)
    setObjectCamera('lock8', 'other')
    addLuaSprite('lock8', true)
    
    makeLuaSprite('lock9', 'freeplay/lock/9', 682, 405)
    setObjectCamera('lock9', 'other')
    addLuaSprite('lock9', true)
    
    makeLuaSprite('select', 'freeplay/lock/select', 555, 260)
    setObjectCamera('select', 'other')
    addLuaSprite('select', true)
    -- end
    
end


-- 440 130 image 1
-- 550 130 image 2
-- 650 130 image 3

-- 450 260 image 4
-- 555 260 image 5
-- 655 260 image 6

-- 440 385 image 7
-- 550 385 image 8
-- 650 385 image 9



-- 470 150 image 1
-- 580 150 image 2
-- 682 150 image 3
-- 485 285 image 4
-- 578 287 image 5
-- 682 277 image 6
-- 470 405 image 7
-- 580 405 image 8
-- 682 405 image 9