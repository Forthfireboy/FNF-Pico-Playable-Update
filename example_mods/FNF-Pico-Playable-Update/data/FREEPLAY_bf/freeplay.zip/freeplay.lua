-- freeplay BF

local images = {}
local selectedIndex = 1
local totalImages = 17
local moveStepX = 50
local moveStepY = 120
local selectedPosX = 380
local selectedPosY = 240
local textPosX = 480
local textPosY = 270

local imageData = {
{file = 'freeplay/bfsongs/dadno', selectedFile = 'freeplay/picosongs/dadno_selected', text = 'bopeebo Erect', resultImage = 'freeplay/picosongs/dadno_result'},

{file = 'freeplay/bfsongs/dadno', selectedFile = 'freeplay/picosongs/dadno_selected', text = 'fresh Erect', resultImage = 'freeplay/picosongs/fresh_result'},

{file = 'freeplay/bfsongs/dadno', selectedFile = 'freeplay/picosongs/dadno_selected', text = 'dad-battle Erect', resultImage = 'freeplay/picosongs/dad-battle_result'},
-- spoki
{file = 'freeplay/bfsongs/spokino', selectedFile = 'freeplay/picosongs/spokino_selected', text = 'spookeez Erect', resultImage = 'freeplay/picosongs/spookeez_result'},

{file = 'freeplay/bfsongs/spokino', selectedFile = 'freeplay/picosongs/spokino_selected', text = 'south Erect', resultImage = 'freeplay/picosongs/south_result'},
-- pico
{file = 'freeplay/bfsongs/picono', selectedFile = 'freeplay/picosongs/picono_selected', text = 'pico Erect', resultImage = 'freeplay/picosongs/pico_result'},

{file = 'freeplay/bfsongs/picono', selectedFile = 'freeplay/picosongs/picono_selected', text = 'philly-nice Erect', resultImage = 'freeplay/picosongs/philly_result'},

{file = 'freeplay/bfsongs/picono', selectedFile = 'freeplay/picosongs/picono_selected', text = 'blammed Erect', resultImage = 'freeplay/picosongs/blammed_result'},
-- mom
{file = 'freeplay/bfsongs/momno', selectedFile = 'freeplay/picosongs/dadmomno_selected', text = 'satin-panties Erect', resultImage = 'freeplay/picosongs/eggnog_result'},

{file = 'freeplay/bfsongs/momno', selectedFile = 'freeplay/picosongs/dadmomno_selected', text = 'high Erect', resultImage = 'freeplay/picosongs/eggnog_result'},
-- navidad
{file = 'freeplay/bfsongs/dadmomno', selectedFile = 'freeplay/picosongs/dadmomno_selected', text = 'cocoa Erect', resultImage = 'freeplay/picosongs/eggnog_result'},

{file = 'freeplay/bfsongs/dadmomno', selectedFile = 'freeplay/picosongs/dadmomno_selected', text = 'eggnog Erect', resultImage = 'freeplay/picosongs/eggnog_result'},
-- sempai
{file = 'freeplay/bfsongs/sempaino', selectedFile = 'freeplay/picosongs/dadmomno_selected', text = 'senpai Erect', resultImage = 'freeplay/picosongs/eggnog_result'},

{file = 'freeplay/bfsongs/sempaino', selectedFile = 'freeplay/picosongs/dadmomno_selected', text = 'roses Erect', resultImage = 'freeplay/picosongs/eggnog_result'},

{file = 'freeplay/bfsongs/spirino', selectedFile = 'freeplay/picosongs/dadmomno_selected', text = 'thorns Erect', resultImage = 'freeplay/picosongs/eggnog_result'},
-- tank
{file = 'freeplay/bfsongs/tankno', selectedFile = 'freeplay/picosongs/tankno_selected', text = 'ugh Erect', resultImage = 'freeplay/picosongs/ugh_result'},
-- darnell
{file = 'freeplay/bfsongs/darnelno', selectedFile = 'freeplay/picosongs/darnelno_selected', text = 'darnell-bf-mix', resultImage = 'freeplay/picosongs/darnell_result'}
}

function onCreate()
    setProperty('skipCountdown', true)
    runTimer('ini', 0.0001)

    makeLuaSprite('bg1', 'freeplay/bg', 0, 0)
    setObjectCamera('bg1', 'other')
    addLuaSprite('bg1')
    
-- letras
    makeLuaSprite('letra1', 'freeplay/letra1', 0, 0)
    setObjectCamera('letra1', 'other')
    addLuaSprite('letra1')
    
    makeLuaSprite('letra12', 'freeplay/letra1', 734, 0)
    setObjectCamera('letra12', 'other')
    addLuaSprite('letra12')
runTimer('letra1', 0.0001)
    
    makeLuaSprite('letra2', 'freeplay/letra2', 0, 0)
    setObjectCamera('letra2', 'other')
    addLuaSprite('letra2')
    
    makeLuaSprite('letra22', 'freeplay/letra2', -672, 0)
    setObjectCamera('letra22', 'other')
    addLuaSprite('letra22')
runTimer('letra2', 0.0001)
    
    makeLuaSprite('letra3', 'freeplay/letra3', 0, 0)
    setObjectCamera('letra3', 'other')
    addLuaSprite('letra3')
    
    makeLuaSprite('letra32', 'freeplay/letra3', 745, 0)
    setObjectCamera('letra32', 'other')
    addLuaSprite('letra32')
runTimer('letra3', 0.0001)
    
    makeLuaSprite('letra4', 'freeplay/letra4', 0, 0)
    setObjectCamera('letra4', 'other')
    addLuaSprite('letra4')
    
    makeLuaSprite('letra42', 'freeplay/letra4', -672, 0)
    setObjectCamera('letra42', 'other')
    addLuaSprite('letra42')
runTimer('letra4', 0.0001)
    
    makeLuaSprite('letra5', 'freeplay/letra5', 0, 0)
    setObjectCamera('letra5', 'other')
    addLuaSprite('letra5')
    
    makeLuaSprite('letra52', 'freeplay/letra5', 733, 0)
    setObjectCamera('letra52', 'other')
    addLuaSprite('letra52')
runTimer('letra5', 0.0001)
    
    makeLuaSprite('letra6', 'freeplay/letra6', 0, 0)
    setObjectCamera('letra6', 'other')
    addLuaSprite('letra6')
    
    makeLuaSprite('letra62', 'freeplay/letra6', -672, 0)
    setObjectCamera('letra62', 'other')
    addLuaSprite('letra62')
runTimer('letra6', 0.0001)
    

-- selected
    makeLuaSprite('bg1sele', 'freeplay/bgsele', 0, 0)
    setObjectCamera('bg1sele', 'other')
    addLuaSprite('bg1sele')
    setProperty('bg1sele.alpha', 0)
    
makeAnimatedLuaSprite('yeah', 'freeplay/yeah', -310, 110)
addAnimationByPrefix('yeah', 'idle', 'idle', 12, true)
scaleObject('yeah', 1, 1)
setObjectCamera('yeah', 'other')
addLuaSprite('yeah', true)
setProperty('yeah.alpha', 0)

-- bf
makeAnimatedLuaSprite('bfbg', 'freeplay/freeplay-bf', -40, -160)
addAnimationByPrefix('bfbg', 'default', 'idle', 10, true)
addAnimationByPrefix('bfbg', 'intro', 'intro', 12, true)
addAnimationByPrefix('bfbg', 'enter', 'Enter', 12, true)
addAnimationByPrefix('bfbg', 'sele', 'selec', 12, true)
scaleObject('bfbg', 1, 1)
setObjectCamera('bfbg', 'other')
addLuaSprite('bfbg', true)
playAnim('bfbg', 'intro', true)
setProperty('bfbg.visible', true)

makeLuaSprite('uiuno', 'freeplay/ui1', 0, 0)
setObjectCamera('uiuno', 'other')
addLuaSprite('uiuno', true)

makeLuaSprite('albu2', 'freeplay/expansion2', 0, 0)
setObjectCamera('albu2', 'other')
addLuaSprite('albu2', true)

    for i = 1, totalImages do
        local imgData = imageData[i]

        makeLuaSprite('bgImage' .. i, 'freeplay/picosongs/fondo', selectedPosX, selectedPosY + (i - selectedIndex) * moveStepY)
        setObjectCamera('bgImage' .. i, 'other')
        addLuaSprite('bgImage' .. i, true)

        makeLuaText('text' .. i, imgData.text, 500, textPosX, textPosY + (i - selectedIndex) * moveStepY)
        setTextAlignment('text' .. i, 'left')
        setObjectCamera('text' .. i, 'other')
        addLuaText('text' .. i)
        setTextSize('text' .. i, 28)

        makeLuaSprite('image' .. i, imgData.file, selectedPosX, selectedPosY + (i - selectedIndex) * moveStepY)
        setObjectCamera('image' .. i, 'other')
        addLuaSprite('image' .. i, true)
        setProperty('image' .. i .. '.alpha', 0.8)
        images[i] = {sprite = 'image' .. i, text = 'text' .. i, bg = 'bgImage' .. i, func = 'imageFunc' .. i, selectedFile = imgData.selectedFile, resultImage = imgData.resultImage}
    end
    
makeLuaSprite('ui2', 'freeplay/ui2', 0, 0)
setObjectCamera('ui2', 'other')
addLuaSprite('ui2', true)

makeLuaSprite('erect', 'freeplay/erect', 0, 0)
setObjectCamera('erect', 'other')
addLuaSprite('erect', true)

    updateImagePositions()
end

function onUpdate()
    if keyJustPressed('up') then
        playSound('scrollMenu',0.8)
        moveSelectionUp()
    elseif keyJustPressed('down') then
        moveSelectionDown()
        playSound('scrollMenu',0.8)
    end
    if keyJustPressed('right') or keyJustPressed('accept') then
        activateCurrentImage()
        doTweenAlpha('bg1.alpha', 'bg1', 0, 0.4, 'linear')
    end
   if keyJustPressed('left') then
       playSound('confirmMenu',0.8)
       runTimer('selec', 1)
       playAnim('bfbg', 'sele', true)
end
end

function moveSelectionUp()
    if selectedIndex > 1 then
        selectedIndex = selectedIndex - 1
        updateImagePositions()
    end
end

function moveSelectionDown()
    if selectedIndex < totalImages then
        selectedIndex = selectedIndex + 1
        updateImagePositions()
    end
end

function updateImagePositions()
    for i = 1, totalImages do
        local img = images[i]
        local offsetY = (i - selectedIndex) * moveStepY

        if i < selectedIndex then
            if i == selectedIndex - 1 then
                doTweenX(img.sprite .. '.x', img.sprite, selectedPosX - 50, 0.2, 'linear')
                doTweenY(img.sprite .. '.y', img.sprite, selectedPosY + offsetY, 0.2, 'linear')
                doTweenX(img.text .. '.x', img.text, textPosX - 50, 0.2, 'linear')
                doTweenY(img.text .. '.y', img.text, textPosY + offsetY, 0.2, 'linear')
                doTweenX(img.bg .. '.x', img.bg, selectedPosX - 50, 0.2, 'linear')
                doTweenY(img.bg .. '.y', img.bg, selectedPosY + offsetY, 0.2, 'linear')
            else
                doTweenY(img.sprite .. '.y', img.sprite, selectedPosY + offsetY, 0.2, 'linear')
                doTweenX(img.text .. '.x', img.text, textPosX - 50, 0.2, 'linear')
                doTweenY(img.text .. '.y', img.text, textPosY + offsetY, 0.2, 'linear')
                doTweenX(img.bg .. '.x', img.bg, selectedPosX - 50, 0.2, 'linear')
                doTweenY(img.bg .. '.y', img.bg, selectedPosY + offsetY, 0.2, 'linear')
            end
            elseif i == selectedIndex then
            doTweenX(img.sprite .. '.x', img.sprite, selectedPosX, 0.2, 'linear')
            doTweenY(img.sprite .. '.y', img.sprite, selectedPosY, 0.2, 'linear')
            doTweenX(img.text .. '.x', img.text, textPosX, 0.2, 'linear')
            doTweenY(img.text .. '.y', img.text, textPosY, 0.2, 'linear')
            doTweenX(img.bg .. '.x', img.bg, selectedPosX, 0.2, 'linear')
            doTweenY(img.bg .. '.y', img.bg, selectedPosY, 0.2, 'linear')
        else
            local offsetX = (i - selectedIndex) * -moveStepX + selectedPosX
            doTweenX(img.sprite .. '.x', img.sprite, offsetX, 0.2, 'linear')
            doTweenY(img.sprite .. '.y', img.sprite, selectedPosY + offsetY, 0.2, 'linear')
            doTweenX(img.text .. '.x', img.text, textPosX + (i - selectedIndex) * -moveStepX, 0.2, 'linear')
            doTweenY(img.text .. '.y', img.text, textPosY + offsetY, 0.2, 'linear')
            doTweenX(img.bg .. '.x', img.bg, offsetX, 0.2, 'linear')
            doTweenY(img.bg .. '.y', img.bg, selectedPosY + offsetY, 0.2, 'linear')
        end

        setProperty(img.sprite .. '.alpha', i == selectedIndex and 1 or 0.8)
    end
end

function activateCurrentImage()
    if selectedIndex > 0 and selectedIndex <= totalImages then
        _G[images[selectedIndex].func]()
    end
end

-- Funciones para cada imagen
function imageFunc1()
runTimer('song1', 1.6)
playSound('confirmMenu',0.8)
doTweenAlpha('bg1sele.alpha', 'bg1sele', 1, 0.4, 'linear')
playAnim('bfbg', 'enter', true)
setProperty('yeah.alpha', 1)
playAnim('yeah', 'idle', true)
end

function imageFunc2()
runTimer('song2', 1.6)
playSound('confirmMenu',0.8)
doTweenAlpha('bg1sele.alpha', 'bg1sele', 1, 0.4, 'linear')
playAnim('bfbg', 'enter', true)
setProperty('yeah.alpha', 1)
playAnim('yeah', 'idle', true)
end

function imageFunc3()
runTimer('song3', 1.6)
playSound('confirmMenu',0.8)
doTweenAlpha('bg1sele.alpha', 'bg1sele', 1, 0.4, 'linear')
playAnim('bfbg', 'enter', true)
setProperty('yeah.alpha', 1)
playAnim('yeah', 'idle', true)
end

function imageFunc4()
runTimer('song4', 1.6)
playSound('confirmMenu',0.8)
doTweenAlpha('bg1sele.alpha', 'bg1sele', 1, 0.4, 'linear')
playAnim('bfbg', 'enter', true)
setProperty('yeah.alpha', 1)
playAnim('yeah', 'idle', true)
end

function imageFunc5()
runTimer('song5', 1.6)
playSound('confirmMenu',0.8)
doTweenAlpha('bg1sele.alpha', 'bg1sele', 1, 0.4, 'linear')
playAnim('bfbg', 'enter', true)
setProperty('yeah.alpha', 1)
playAnim('yeah', 'idle', true)
end

function imageFunc6()
runTimer('song6', 1.6)
playSound('confirmMenu',0.8)
doTweenAlpha('bg1sele.alpha', 'bg1sele', 1, 0.4, 'linear')
playAnim('bfbg', 'enter', true)
setProperty('yeah.alpha', 1)
playAnim('yeah', 'idle', true)
end

function imageFunc7()
runTimer('song7', 1.6)
playSound('confirmMenu',0.8)
doTweenAlpha('bg1sele.alpha', 'bg1sele', 1, 0.4, 'linear')
playAnim('bfbg', 'enter', true)
setProperty('yeah.alpha', 1)
playAnim('yeah', 'idle', true)
end

function imageFunc8()
runTimer('song8', 1.6)
playSound('confirmMenu',0.8)
doTweenAlpha('bg1sele.alpha', 'bg1sele', 1, 0.4, 'linear')
playAnim('bfbg', 'enter', true)
setProperty('yeah.alpha', 1)
playAnim('yeah', 'idle', true)
end

function imageFunc9()
runTimer('song9', 1.6)
playSound('confirmMenu',0.8)
doTweenAlpha('bg1sele.alpha', 'bg1sele', 1, 0.4, 'linear')
playAnim('bfbg', 'enter', true)
setProperty('yeah.alpha', 1)
playAnim('yeah', 'idle', true)
end

function imageFunc10()
runTimer('song10', 1.6)
playSound('confirmMenu',0.8)
doTweenAlpha('bg1sele.alpha', 'bg1sele', 1, 0.4, 'linear')
playAnim('bfbg', 'enter', true)
setProperty('yeah.alpha', 1)
playAnim('yeah', 'idle', true)
end

function imageFunc11()
runTimer('song11', 1.6)
playSound('confirmMenu',0.8)
doTweenAlpha('bg1sele.alpha', 'bg1sele', 1, 0.4, 'linear')
playAnim('bfbg', 'enter', true)
setProperty('yeah.alpha', 1)
playAnim('yeah', 'idle', true)
end

function imageFunc12()
runTimer('song12', 1.6)
playSound('confirmMenu',0.8)
doTweenAlpha('bg1sele.alpha', 'bg1sele', 1, 0.4, 'linear')
playAnim('bfbg', 'enter', true)
setProperty('yeah.alpha', 1)
playAnim('yeah', 'idle', true)
end

function imageFunc13()
runTimer('song13', 1.6)
playSound('confirmMenu',0.8)
doTweenAlpha('bg1sele.alpha', 'bg1sele', 1, 0.4, 'linear')
playAnim('bfbg', 'enter', true)
setProperty('yeah.alpha', 1)
playAnim('yeah', 'idle', true)
end

function imageFunc14()
runTimer('song14', 1.6)
playSound('confirmMenu',0.8)
doTweenAlpha('bg1sele.alpha', 'bg1sele', 1, 0.4, 'linear')
playAnim('bfbg', 'enter', true)
setProperty('yeah.alpha', 1)
playAnim('yeah', 'idle', true)
end

function imageFunc15()
runTimer('song15', 1.6)
playSound('confirmMenu',0.8)
doTweenAlpha('bg1sele.alpha', 'bg1sele', 1, 0.4, 'linear')
playAnim('bfbg', 'enter', true)
setProperty('yeah.alpha', 1)
playAnim('yeah', 'idle', true)
end

function imageFunc16()
runTimer('song16', 1.6)
playSound('confirmMenu',0.8)
doTweenAlpha('bg1sele.alpha', 'bg1sele', 1, 0.4, 'linear')
playAnim('bfbg', 'enter', true)
setProperty('yeah.alpha', 1)
playAnim('yeah', 'idle', true)
end

function imageFunc17()
runTimer('song17', 1.6)
playSound('confirmMenu',0.8)
doTweenAlpha('bg1sele.alpha', 'bg1sele', 1, 0.4, 'linear')
playAnim('bfbg', 'enter', true)
setProperty('yeah.alpha', 1)
playAnim('yeah', 'idle', true)
end

function onTimerCompleted(tag, loops, loopsLeft)
    
    if tag == 'letra1' then
doTweenX('letra1.x', 'letra1', -734, 3, 'linear')
doTweenX('letra12.x', 'letra12', 0, 3, 'linear')

runTimer('letra1regre', 3)
elseif tag == 'letra1regre' then
doTweenX('letra1.x', 'letra1',0, 0.0001, 'linear')
doTweenX('letra12.x', 'letra12', 734, 0.0001, 'linear')

runTimer('letra1', 0.0001)
end

    if tag == 'letra2' then
doTweenX('letra2.x', 'letra2', 672, 5, 'linear')
doTweenX('letra22.x', 'letra22', 0, 5, 'linear')

runTimer('letra2regre', 5)

elseif tag == 'letra2regre' then
doTweenX('letra2.x', 'letra2',0, 0.0001, 'linear')
doTweenX('letra22.x', 'letra22', -672, 0.0001, 'linear')

runTimer('letra2', 0.0001)
end

    if tag == 'letra3' then
doTweenX('letra3.x', 'letra3', -745, 3, 'linear')
doTweenX('letra32.x', 'letra32', 0, 3, 'linear')

runTimer('letra3regre', 3)
elseif tag == 'letra3regre' then
doTweenX('letra1.x', 'letra3',0, 0.0001, 'linear')
doTweenX('letra32.x', 'letra32', 745, 0.0001, 'linear')

runTimer('letra3', 0.0001)
end

    if tag == 'letra4' then
doTweenX('letra4.x', 'letra4', 672, 5, 'linear')
doTweenX('letra42.x', 'letra42', 0, 5, 'linear')

runTimer('letra4regre', 5)
elseif tag == 'letra4regre' then
doTweenX('letra4.x', 'letra4',0, 0.0001, 'linear')
doTweenX('letra42.x', 'letra42', -672, 0.0001, 'linear')

runTimer('letra4', 0.0001)
end

    if tag == 'letra5' then
doTweenX('letra5.x', 'letra5', -733, 3, 'linear')
doTweenX('letra52.x', 'letra52', 0, 3, 'linear')

runTimer('letra5regre', 3)
elseif tag == 'letra5regre' then
doTweenX('letra5.x', 'letra5',0, 0.0001, 'linear')
doTweenX('letra52.x', 'letra52', 733, 0.0001, 'linear')

runTimer('letra5', 0.0001)
end

    if tag == 'letra6' then
doTweenX('letra6.x', 'letra6', 672, 5, 'linear')
doTweenX('letra62.x', 'letra62', 0, 5, 'linear')

runTimer('letra6regre', 5)
elseif tag == 'letra6regre' then
doTweenX('letra6.x', 'letra6',0, 0.0001, 'linear')
doTweenX('letra62.x', 'letra62', -672, 0.0001, 'linear')

runTimer('letra6', 0.0001)
end

if tag == 'selec' then
loadSong('selecciona_personaje')
end

   if tag == 'song1' then
loadSong('bopeebo-Erect')
end

   if tag == 'song2' then
loadSong('fresh-Erect')
end

   if tag == 'song3' then
loadSong('dad-battle-Erect')
end

   if tag == 'song4' then
loadSong('spookeez-Erect')
end

   if tag == 'song5' then
loadSong('south-Erect')
end

   if tag == 'song6' then
loadSong('pico-Erect')
end

   if tag == 'song7' then
loadSong('philly-nice-Erect')
end

   if tag == 'song8' then
loadSong('blammed-Erect')
end

   if tag == 'song9' then
loadSong('satin-panties-Erect')
end

   if tag == 'song10' then
loadSong('high-Erect')
end

   if tag == 'song11' then
loadSong('cocoa-Erect')
end

   if tag == 'song12' then
loadSong('eggnog-Erect')
end

   if tag == 'song13' then
loadSong('senpai-Erect')
end

   if tag == 'song14' then
loadSong('roses-Erect')
end

   if tag == 'song15' then
loadSong('thorns-Erect')
end

   if tag == 'song16' then
loadSong('ugh-Erect')
end

   if tag == 'song17' then
loadSong('darnell-bf-mix')
end
end

function onStepHit()
if curStep == 6 then
playAnim('bfbg', 'default', true)
end
end

function onEndSong()
restartSong(true);
end